# Mini Portfólio JavaScript

Projetos simples desenvolvidos com JavaScript puro para treinar lógica de programação e estrutura de dados.

## Projetos

1. **Lista de Compras com Desconto:** Adiciona produtos com categoria e aplica descontos automáticos.
2. **Registro de Pessoas:** Registra nome, idade e classifica por faixa etária.

Para executar: abra o `index.html` de cada pasta com um navegador moderno.
